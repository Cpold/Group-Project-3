/*
 * @author Rachapon - 6713247
 * Ratchasin - 6713247
 * Sayklang - 6713250
 * Chayapol - 6713223
 * Zabit - 6713116
 */
package Project3_6713223;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartScene extends JPanel implements ActionListener {
    
    private SceneManager sceneManager;
    private JTextField nameInputField; 
    private JButton backButton, nextButton;
    
    public StartScene(SceneManager sceneManager) {
        this.sceneManager = sceneManager;
        
        // 1. ตั้งค่าพื้นฐาน
        this.setPreferredSize(new Dimension(MyConstants.WIDTH, MyConstants.HEIGHT));
        this.setLayout(null); // ใช้ null Layout หลัก
        this.setOpaque(false);
        
        // 2. สร้าง Components
        
        // 2.1 Title/Prompt
        JLabel promptLabel = new JLabel("ENTER YOUR NAME:", SwingConstants.LEFT); 
        promptLabel.setFont(new Font("Arial", Font.BOLD, 36));
        promptLabel.setForeground(Color.BLACK);
        
        // 2.2 JTextField สำหรับใส่ชื่อ
        nameInputField = new JTextField(15); 
        nameInputField.setFont(new Font("Monospaced", Font.PLAIN, 24));
        nameInputField.setHorizontalAlignment(JTextField.CENTER);
        
        // 3. จัดวาง Components กลางหน้าจอ (ใช้ JPanel ย่อยสำหรับจัดวาง)
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // 3.1 วาง Prompt Label (ชิดซ้ายของพื้นที่ GBC)
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST; // ให้ Label ชิดซ้ายในคอลัมน์ของมัน
        centerPanel.add(promptLabel, gbc);
        
        // 3.2 วาง Input Field
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER; // ให้ Input Field อยู่ตรงกลาง
        centerPanel.add(nameInputField, gbc);
        
        // 4. กำหนดตำแหน่ง Center Panel บน StartScene
        int panelWidth = 500;
        int panelHeight = 200;
        centerPanel.setBounds(MyConstants.WIDTH / 2 - panelWidth / 2, MyConstants.HEIGHT / 2 - 100, panelWidth, panelHeight);
        this.add(centerPanel);
        
        // 5. สร้างปุ่ม BACK และ NEXT (จัดวางด้วย null layout)
        
        // 5.1 ปุ่ม BACK
        backButton = createStyledButton("BACK", 150, 50);
        backButton.addActionListener(this);
        backButton.setBounds(50, MyConstants.HEIGHT - 120, 150, 50);
        this.add(backButton);
        
        // 5.2 ปุ่ม NEXT
        nextButton = createStyledButton("NEXT", 150, 50);
        nextButton.addActionListener(this);
        nextButton.setBounds(MyConstants.WIDTH - 200, MyConstants.HEIGHT - 120, 150, 50);
        this.add(nextButton);
    }
    
    private JButton createStyledButton(String text, int width, int height) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 24));
        btn.setPreferredSize(new Dimension(width, height));
        btn.setForeground(Color.WHITE); 
        
        btn.setBackground(new Color(139, 69, 19)); 
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        return btn;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            sceneManager.switchToScene("Menu"); 
        } else if (e.getSource() == nextButton) {
            
            String playerName = nameInputField.getText().trim();
            
            // *** บังคับให้ใส่ชื่อผู้เล่น ***
            if (playerName.isEmpty()) {
                // แสดงข้อความแจ้งเตือนถ้าช่องว่าง
                JOptionPane.showMessageDialog(this, 
                                              "Please enter your name to continue.", 
                                              "Input Required", 
                                              JOptionPane.WARNING_MESSAGE);
                nameInputField.requestFocusInWindow(); // กลับไปโฟกัสที่ช่องใส่ชื่อ
                return; // หยุดการทำงาน ไม่เปลี่ยนฉาก
            }
            
            // ผ่านเงื่อนไข: เปลี่ยนไปฉากเลือกความยาก
            sceneManager.switchToScene("Difficulty");
        }
    }
}