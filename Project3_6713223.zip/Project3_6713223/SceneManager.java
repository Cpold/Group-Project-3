/*
 * @author Rachapon - 6713247
 * Ratchasin - 6713247
 * Sayklang - 6713250
 * Chayapol - 6713223
 * Zabit - 6713116
 */
package Project3_6713223;

import javax.swing.*;
import java.awt.*; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; // <<< ต้องมี

public class SceneManager {
    
    private JFrame mainFrame;
    private MainMenuScene mainMenu;
    private GameBoard gameBoard;
    private CreditScene creditScene;
    private StartScene startInputScene; 
    private DifficultyScene difficultyScene;
    
    public SceneManager(JFrame mainFrame) {
        this.mainFrame = mainFrame;
        
        // แก้ไข: Constructor ต้องรับ SceneManager
        mainMenu = new MainMenuScene(this); 
        creditScene = new CreditScene(this); 
        startInputScene = new StartScene(this); 
        difficultyScene = new DifficultyScene(this);
    }
    
    // 1. เพิ่มเมธอดที่ขาดหายไป: สำหรับ MainApplication เรียกเพื่อดึง Menu Scene
    public MainMenuScene getMainMenuScene() {
        return mainMenu;
    }
    
    // 2. เมธอดสำหรับซ่อน/แสดง Volume Icon
    private void toggleVolumeIcon(boolean visible) {
        if (mainFrame instanceof MainApplication) {
            try {
                // เรียกใช้ getVolumeIcon() ที่เพิ่มใน MainApplication
                JButton volumeIcon = ((MainApplication) mainFrame).getVolumeIcon();
                if (volumeIcon != null) {
                    volumeIcon.setVisible(visible);
                }
            } catch (Exception e) {
                // ข้อความแจ้งเตือนถ้า MainApplication.getVolumeIcon() ไม่ถูกต้อง
                System.err.println("Error accessing Volume Icon: Make sure getVolumeIcon() is public in MainApplication.");
            }
        }
    }
    
    // 3. คลาสสำหรับปุ่ม BACK ใน Tutorial Scene (แก้ปัญหา Class Visibility)
    private class BackButtonPanel extends JPanel implements ActionListener {
        
        private JButton backButton;
        private SceneManager sm;

        public BackButtonPanel(SceneManager sm) {
            this.sm = sm; 
            this.setLayout(null);
            this.setOpaque(false);
            
            JLabel placeholder = new JLabel("TUTORIAL/SETTING SCREEN", SwingConstants.CENTER);
            placeholder.setFont(new Font("Arial", Font.BOLD, 30));
            placeholder.setForeground(Color.WHITE);
            placeholder.setBounds(MyConstants.WIDTH/2 - 300, MyConstants.HEIGHT/2 - 50, 600, 100);
            this.add(placeholder);

            backButton = new JButton("BACK");
            backButton.setFont(new Font("Arial", Font.BOLD, 24));
            backButton.setPreferredSize(new Dimension(150, 50));
            backButton.addActionListener(this);
            
            backButton.setForeground(Color.BLACK);
            backButton.setBackground(new Color(255, 255, 255, 200));
            backButton.setOpaque(true);
            backButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            
            backButton.setBounds(50, MyConstants.HEIGHT - 120, 150, 50); 
            this.add(backButton);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == backButton) {
                sm.switchToScene("Menu"); 
            }
        }
    }

    public void switchToScene(String sceneName) {
        Container contentPane = mainFrame.getContentPane();
        
        Component[] components = contentPane.getComponents();
        for (Component c : components) {
            if (!(c instanceof JSlider) && !(c instanceof JButton) && !c.getClass().getName().contains("volumeControlPanel")) {
                 if (c.getWidth() == MyConstants.WIDTH && c.getHeight() == MyConstants.HEIGHT) {
                    contentPane.remove(c);
                 }
            }
        }
        
        // จัดการ Volume Icon: ซ่อนเมื่อเข้าฉาก Game/StartInput/Difficulty
        toggleVolumeIcon(sceneName.equals("Menu") || sceneName.equals("Credit") || sceneName.equals("Tutorial")); 
        
        switch (sceneName) {
            case "Menu":
                mainFrame.setTitle("Restaurant Game - Main Menu");
                mainMenu.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(mainMenu);
                break;
            case "StartInput": // ฉากใส่ชื่อ
                mainFrame.setTitle("Restaurant Game - Enter Name");
                startInputScene.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(startInputScene);
                startInputScene.revalidate();
                startInputScene.repaint();
                break;
            case "Difficulty": // ฉากเลือกความยาก
                mainFrame.setTitle("Restaurant Game - Select Mode");
                difficultyScene.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(difficultyScene);
                difficultyScene.revalidate();
                difficultyScene.repaint();
                break;
            case "Game":
                mainFrame.setTitle("Restaurant Game - Gameplay");
                if (gameBoard == null) {
                    gameBoard = new GameBoard();
                }
                gameBoard.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(gameBoard);
                gameBoard.requestFocusInWindow();
                break;
            case "Credit": 
                mainFrame.setTitle("Restaurant Game - Credits");
                creditScene.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(creditScene);
                break;
            case "Tutorial": 
                mainFrame.setTitle("Restaurant Game - Tutorial/Setting");
                BackButtonPanel tutorialPanel = new BackButtonPanel(this); 
                tutorialPanel.setBounds(0, 0, MyConstants.WIDTH, MyConstants.HEIGHT);
                contentPane.add(tutorialPanel);
                break;
            case "End":
                // ถ้ามี EndScene ให้สร้างและเพิ่ม
                break;
            default:
                System.err.println("Unknown scene: " + sceneName);
        }
        
        contentPane.revalidate();
        contentPane.repaint();
    }
}