/*
 * @author Rachapon - 6713247
 * Ratchasin - 6713247
 * Sayklang - 6713250
 * Chayapol - 6713223
 * Zabit - 6713116
 */
package Project3_6713223;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuScene extends JPanel implements ActionListener {
    
    private JButton startButton, creditsButton, tutorialButton, exitButton; 
    private JButton testWinButton, testLostButton; 
    private SceneManager sceneManager;
    
    public MainMenuScene(SceneManager sceneManager) {
        this.sceneManager = sceneManager;
        
        this.setOpaque(false);
        this.setLayout(new GridBagLayout()); 
        
        Font buttonFont = new Font("Arial", Font.BOLD, 24);
        int buttonWidth = 200;
        int buttonHeight = 50;
        
        // Load Images
        MyImageIcon startIcon = ImageLoader.loadImageIcon(MyConstants.BUTTON_START_IMG);
        MyImageIcon creditsIcon = ImageLoader.loadImageIcon(MyConstants.BUTTON_CREDITS_IMG);
        MyImageIcon tutorialIcon = ImageLoader.loadImageIcon(MyConstants.BUTTON_TUTORIAL_IMG);
        MyImageIcon exitIcon = ImageLoader.loadImageIcon(MyConstants.BUTTON_EXIT_IMG);

        // Create Main Buttons
        startButton = createStyledButton("", buttonFont, buttonWidth, buttonHeight, startIcon);
        creditsButton = createStyledButton("", buttonFont, buttonWidth, buttonHeight, creditsIcon);
        tutorialButton = createStyledButton("", buttonFont, buttonWidth, buttonHeight, tutorialIcon);
        exitButton = createStyledButton("", buttonFont, buttonWidth, buttonHeight, exitIcon);
        
        // Create Test Buttons (Small)
        Font testButtonFont = new Font("Arial", Font.PLAIN, 12); 
        int testButtonWidth = 120; 
        int testButtonHeight = 25; 
        
        testWinButton = createStyledButton("TEST END SCENE (WIN)", testButtonFont, testButtonWidth, testButtonHeight, null); 
        testLostButton = createStyledButton("TEST END SCENE (LOST)", testButtonFont, testButtonWidth, testButtonHeight, null); 
        
        // Add Listeners
        startButton.addActionListener(this);
        creditsButton.addActionListener(this);
        tutorialButton.addActionListener(this);
        exitButton.addActionListener(this);
        testWinButton.addActionListener(this); 
        testLostButton.addActionListener(this); 

        // 1. จัดวาง Components หลักด้วย GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.gridx = 0; 
        gbc.fill = GridBagConstraints.NONE; 
        gbc.anchor = GridBagConstraints.CENTER; 
        
        // ปุ่ม START (0)
        gbc.gridy = 0; 
        gbc.weighty = 0; 
        // **[ปรับแก้ไข]** เพิ่มค่า insets ด้านบนเป็น 300 เพื่อดันปุ่มลงตามต้องการ
        gbc.insets = new Insets(300, 0, 10, 0); 
        this.add(startButton, gbc);
        
        // ปุ่ม CREDITS (1)
        gbc.gridy = 1; 
        gbc.insets = new Insets(10, 0, 10, 0); 
        this.add(creditsButton, gbc);
        
        // ปุ่ม TUTORIAL (2)
        gbc.gridy = 2; 
        this.add(tutorialButton, gbc);
        
        // ปุ่ม EXIT (3)
        gbc.gridy = 3; 
        this.add(exitButton, gbc);
        
        // ------------------------------------------------------------------
        // 2. จัดวางปุ่มทดสอบ 2 ปุ่มเล็กๆ ไว้ใน Panel แยก (ชิดล่าง)
        
        JPanel testPanel = new JPanel(new GridBagLayout());
        testPanel.setOpaque(false); 
        
        GridBagConstraints testGbc = new GridBagConstraints();
        testGbc.anchor = GridBagConstraints.CENTER;
        testGbc.insets = new Insets(0, 5, 0, 5); 
        
        // ปุ่ม WIN
        testGbc.gridx = 0;
        testGbc.gridy = 0;
        testPanel.add(testWinButton, testGbc);
        
        // ปุ่ม LOST
        testGbc.gridx = 1;
        testPanel.add(testLostButton, testGbc);
        
        // 3. เพิ่ม Panel ทดสอบเข้าไปใน Main Menu (ชิดล่าง)
        gbc.gridy = 4; // แถวล่างสุดถัดจาก Exit
        gbc.gridx = 0;
        gbc.weighty = 1.0; // **จุดสำคัญ:** ให้แถวนี้ขยายเต็มที่ ผลักปุ่มไปด้านล่าง
        gbc.insets = new Insets(0, 0, 30, 0); // ระยะห่างด้านล่าง 30px
        gbc.fill = GridBagConstraints.NONE; 
        this.add(testPanel, gbc); 
        // ------------------------------------------------------------------
    }
    
    private JButton createStyledButton(String text, Font font, int width, int height, MyImageIcon icon) {
        JButton btn = new JButton(text);
        btn.setFont(font);
        btn.setPreferredSize(new Dimension(width, height));
        btn.setForeground(Color.BLACK); 
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false); 
        
        if (icon != null) {
            Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            btn.setIcon(new ImageIcon(scaledImage));
            btn.setHorizontalTextPosition(SwingConstants.CENTER);
            btn.setVerticalTextPosition(SwingConstants.CENTER);
        } else {
             btn.setBackground(new Color(255, 255, 255, 200)); 
             btn.setOpaque(true);
             btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        }
        return btn;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String testPlayerName = "DEV_TESTER"; 
        
        if (e.getSource() == startButton) {
            sceneManager.switchToScene("StartInput");
        } else if (e.getSource() == creditsButton) {
            sceneManager.switchToScene("Credit");
        } else if (e.getSource() == tutorialButton) { 
            sceneManager.switchToScene("Tutorial"); 
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        } else if (e.getSource() == testWinButton) { 
            sceneManager.showEndScene(true, testPlayerName); 
        } else if (e.getSource() == testLostButton) { 
            sceneManager.showEndScene(false, testPlayerName); 
        }
    }
}